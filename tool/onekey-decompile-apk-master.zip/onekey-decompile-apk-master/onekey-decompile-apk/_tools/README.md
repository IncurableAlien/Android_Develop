# 辅助工具

## 反编译工具
* [javOSize](https://www.javosize.com/)
  
  you can do whatever you are able to code or someone else has been able to code
* [Procyon Java Decompiler](https://bitbucket.org/mstrobel/procyon/wiki/Java%20Decompiler) 
  
  handle language enhancements from Java 5 and beyond that most other decompilers don't.
* [google/enjarify](https://github.com/google/enjarify)
  
  translating Dalvik bytecode to equivalent Java bytecode